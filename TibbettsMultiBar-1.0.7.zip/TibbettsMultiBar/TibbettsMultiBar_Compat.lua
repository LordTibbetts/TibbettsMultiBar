local addonName, addon = ...

addon = addon or {}
addon.Compat = addon.Compat or {}
local C = addon.Compat

-- Safely call an object method if it exists (prevents nil method crashes on older clients).
function C.SafeCall(obj, method, ...)
    if obj and method and obj[method] then
        return obj[method](obj, ...)
    end
end

-- Cross-client "enabled" helper: some widgets use Enable/Disable instead of SetEnabled.
function C.SetEnabled(frame, enabled)
    if not frame then return end
    enabled = enabled and true or false

    if frame.SetEnabled then
        frame:SetEnabled(enabled)
    else
        if enabled and frame.Enable then frame:Enable() end
        if (not enabled) and frame.Disable then frame:Disable() end
    end

    -- Optional visual/mouse feedback (safe on most frames)
    if frame.SetAlpha then frame:SetAlpha(enabled and 1 or 0.5) end
    if frame.EnableMouse then frame:EnableMouse(enabled) end
end

-- Cross-client solid color texture helper.
-- Retail has Texture:SetColorTexture; WotLK/older does not.
function C.SetSolidColor(tex, r, g, b, a)
    if not tex then return end
    a = tonumber(a) or 1
    if a < 0 then a = 0 elseif a > 1 then a = 1 end

    if tex.SetColorTexture then
        tex:SetColorTexture(tonumber(r) or 0, tonumber(g) or 0, tonumber(b) or 0, a)
        return
    end

    -- WotLK-safe fallback
    if tex.SetTexture then
        tex:SetTexture('Interface\\Buttons\\WHITE8X8')
    end
    if tex.SetVertexColor then
        tex:SetVertexColor(tonumber(r) or 0, tonumber(g) or 0, tonumber(b) or 0, a)
    end
end

-- Feature detection for Retail Settings API (optional convenience).
function C.HasModernSettings()
    return _G.Settings and _G.Settings.RegisterCanvasLayoutCategory and true or false
end
